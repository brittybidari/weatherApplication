//
//  ListDataFetchClass.swift
//  weather
//
//  Created by Britty Bidari on 27/07/2021.
//

import Foundation
