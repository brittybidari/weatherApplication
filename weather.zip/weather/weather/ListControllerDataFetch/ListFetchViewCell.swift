//
//  ListFetchViewCell.swift
//  weather
//
//  Created by Britty Bidari on 27/07/2021.
//

import UIKit

class ListFetchViewCell: UICollectionViewCell {
    
    @IBOutlet weak var weatherImageIcon: UIImageView!
    @IBOutlet weak var dateValue: UILabel!
    @IBOutlet weak var dayValue: UILabel!
}
